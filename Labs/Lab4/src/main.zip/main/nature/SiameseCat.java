package nature;

public class SiameseCat extends HouseCat
{
    public SiameseCat(String name)
    {
        super(name);
    }
    
    public void makeNoise()
    {
        System.out.println("mrrooowwww ...");
    }

    public void play()
    {
        System.out.println("zoom zoom zoom ...");
    }
}
