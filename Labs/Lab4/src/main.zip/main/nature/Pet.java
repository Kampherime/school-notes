package nature;

public interface Pet
{
    public void play();

    public void beFriendly();
}
